package sqlite_test

import (
	"context"
	"palm/src/entities"
	"palm/src/repositories"
	"palm/src/repositories/sqlite"
	"palm/tests/utils"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestAttachmentRepository_Create(t *testing.T) {
	db := utils.SetupTestDB(t)
	repo := sqlite.NewAttachmentRepository(db)
	ctx := context.Background()

	// Create test account using helper
	account := utils.CreateTestAccount(t, db, "test@example.com", entities.AccountTypeMicrosoft)

	// Create test message using helper
	subject := "Test Subject"
	message := utils.CreateTestMessage(t, db, account.ID, subject, "sender@example.com", entities.ImportanceNormal)

	attachment := &entities.Attachment{
		MessageID: message.MessageID,
		Filename:  "test.pdf",
		MimeType:  "application/pdf",
		Size:      1024,
	}

	err := repo.Create(ctx, attachment)
	assert.NoError(t, err)
	assert.Greater(t, attachment.AttachmentID, int64(0), "Attachment ID should be set after create")

	// Verify in DB
	var dbAttachment entities.Attachment
	err = db.First(&dbAttachment, attachment.AttachmentID).Error
	assert.NoError(t, err)
	assert.Equal(t, message.MessageID, dbAttachment.MessageID)
	assert.Equal(t, attachment.Filename, dbAttachment.Filename)
	assert.Equal(t, attachment.MimeType, dbAttachment.MimeType)
	assert.Equal(t, attachment.Size, dbAttachment.Size)
}

func TestAttachmentRepository_GetByID(t *testing.T) {
	db := utils.SetupTestDB(t)
	repo := sqlite.NewAttachmentRepository(db)
	ctx := context.Background()

	// Create test account using helper
	account := utils.CreateTestAccount(t, db, "test@example.com", entities.AccountTypeMicrosoft)

	// Create test message using helper
	subject := "Test Subject"
	message := utils.CreateTestMessage(t, db, account.ID, subject, "sender@example.com", entities.ImportanceNormal)

	// Create test attachment using helper
	testAttachment := utils.CreateTestAttachment(t, db, message.MessageID, "test.pdf", "application/pdf", 1024)

	t.Run("Existing ID", func(t *testing.T) {
		attachment, err := repo.GetByID(ctx, testAttachment.AttachmentID)
		assert.NoError(t, err)
		assert.NotNil(t, attachment)
		assert.Equal(t, testAttachment.AttachmentID, attachment.AttachmentID)
		assert.Equal(t, testAttachment.MessageID, attachment.MessageID)
		assert.Equal(t, testAttachment.Filename, attachment.Filename)
		assert.Equal(t, testAttachment.MimeType, attachment.MimeType)
		assert.Equal(t, testAttachment.Size, attachment.Size)
	})

	t.Run("Non-existing ID", func(t *testing.T) {
		_, err := repo.GetByID(ctx, 9999)
		assert.Error(t, err)
		assert.ErrorIs(t, err, repositories.ErrAttachmentNotFound)
	})
}

func TestAttachmentRepository_GetByMessageID(t *testing.T) {
	db := utils.SetupTestDB(t)
	repo := sqlite.NewAttachmentRepository(db)
	ctx := context.Background()

	// Create test account using helper
	account := utils.CreateTestAccount(t, db, "test@example.com", entities.AccountTypeMicrosoft)

	// Create test message using helper
	subject := "Test Subject"
	message := utils.CreateTestMessage(t, db, account.ID, subject, "sender@example.com", entities.ImportanceNormal)

	// Create test attachments using helper
	utils.CreateTestAttachment(t, db, message.MessageID, "test1.pdf", "application/pdf", 1024)
	utils.CreateTestAttachment(t, db, message.MessageID, "test2.jpg", "image/jpeg", 2048)

	t.Run("Get Attachments for Existing Message", func(t *testing.T) {
		fetchedAttachments, err := repo.GetByMessageID(ctx, message.MessageID)
		assert.NoError(t, err)
		assert.Len(t, fetchedAttachments, 2)

		// Verify attachment filenames
		filenames := []string{fetchedAttachments[0].Filename, fetchedAttachments[1].Filename}
		assert.Contains(t, filenames, "test1.pdf")
		assert.Contains(t, filenames, "test2.jpg")
	})

	t.Run("Get Attachments for Non-existing Message", func(t *testing.T) {
		fetchedAttachments, err := repo.GetByMessageID(ctx, 9999)
		assert.NoError(t, err) // Should not error for non-existing message
		assert.Empty(t, fetchedAttachments)
	})
}

func TestAttachmentRepository_DeleteByMessageID(t *testing.T) {
	db := utils.SetupTestDB(t)
	repo := sqlite.NewAttachmentRepository(db)
	ctx := context.Background()

	// Create test account using helper
	account := utils.CreateTestAccount(t, db, "test@example.com", entities.AccountTypeMicrosoft)

	// Create test messages using helpers
	subject1 := "Test Subject 1"
	subject2 := "Test Subject 2"
	message1 := utils.CreateTestMessage(t, db, account.ID, subject1, "sender1@example.com", entities.ImportanceNormal)
	message2 := utils.CreateTestMessage(t, db, account.ID, subject2, "sender2@example.com", entities.ImportanceNormal)

	// Create test attachments using helpers
	utils.CreateTestAttachment(t, db, message1.MessageID, "test1.pdf", "application/pdf", 1024)
	utils.CreateTestAttachment(t, db, message1.MessageID, "test2.jpg", "image/jpeg", 2048)
	utils.CreateTestAttachment(t, db, message2.MessageID, "test3.txt", "text/plain", 512)

	t.Run("Delete Attachments for Existing Message", func(t *testing.T) {
		err := repo.DeleteByMessageID(ctx, message1.MessageID)
		assert.NoError(t, err)

		// Verify attachments for message1 are deleted
		var count int64
		db.Model(&entities.Attachment{}).Where("message_id = ?", message1.MessageID).Count(&count)
		assert.Equal(t, int64(0), count)

		// Verify attachments for message2 still exist
		db.Model(&entities.Attachment{}).Where("message_id = ?", message2.MessageID).Count(&count)
		assert.Equal(t, int64(1), count)
	})

	t.Run("Delete Attachments for Non-existing Message", func(t *testing.T) {
		err := repo.DeleteByMessageID(ctx, 9999)
		assert.NoError(t, err) // Should not error for non-existing message ID
	})
}
