package utils

import (
	"palm/src/entities"
	"testing"

	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

// CreateTestAccount creates a test account and returns it
func CreateTestAccount(t *testing.T, db *gorm.DB, email string, accountType string) *entities.Account {
	account := &entities.Account{
		Email:       email,
		AccountType: accountType,
	}
	err := db.Create(account).Error
	require.NoError(t, err, "Failed to create test account")
	return account
}

// CreateTestMessage creates a test message linked to an account and returns it
func CreateTestMessage(t *testing.T, db *gorm.DB, accountID int64, subject string, senderEmail string, importance entities.Importance) *entities.Message {
	// Verify account exists
	var account entities.Account
	err := db.First(&account, accountID).Error
	require.NoError(t, err, "Account must exist before creating message")

	message := &entities.Message{
		AccountID:   accountID,
		Subject:     &subject,
		SenderEmail: senderEmail,
		Importance:  importance,
	}
	err = db.Create(message).Error
	require.NoError(t, err, "Failed to create test message")
	return message
}

// CreateTestRecipient creates a test recipient linked to a message and returns it
func CreateTestRecipient(t *testing.T, db *gorm.DB, messageID int64, email string, name string, recipientType entities.RecipientType) *entities.Recipient {
	// Verify message exists
	var message entities.Message
	err := db.First(&message, messageID).Error
	require.NoError(t, err, "Message must exist before creating recipient")

	recipient := &entities.Recipient{
		MessageID:     messageID,
		Email:         email,
		Name:          &name,
		RecipientType: recipientType,
	}
	err = db.Create(recipient).Error
	require.NoError(t, err, "Failed to create test recipient")
	return recipient
}

// CreateTestAttachment creates a test attachment linked to a message and returns it
func CreateTestAttachment(t *testing.T, db *gorm.DB, messageID int64, filename string, mimeType string, size int64) *entities.Attachment {
	// Verify message exists
	var message entities.Message
	err := db.First(&message, messageID).Error
	require.NoError(t, err, "Message must exist before creating attachment")

	attachment := &entities.Attachment{
		MessageID: messageID,
		Filename:  filename,
		MimeType:  mimeType,
		Size:      size,
	}
	err = db.Create(attachment).Error
	require.NoError(t, err, "Failed to create test attachment")
	return attachment
}
